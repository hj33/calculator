package com.hw.test;

public class Galaxy implements Phone{

	@Override
	public void powerOn() {
		System.out.println("갤럭시: 전원 켜기!");
	}

	@Override
	public void powerOff() {
		System.out.println("갤럭시: 전원 끄기");
	}

	@Override
	public void volumeUp() {
		System.out.println("갤럭시: 전화 볼륨 up!");
	}

	@Override
	public void volumeDown() {
		System.out.println("갤럭시: 전화 볼륨 down!");
	}
	
}
