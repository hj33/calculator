package com.hw.test;


public class PhoneFactory {
	
	// 어떤 클래스 객체를 사용할 것인지 결정하기 위해 작성.
	
	public Phone getBean(String phone){
		if(phone.equals("Galaxy")){
			return new Galaxy();
		} else if(phone.equals("iPhone")){
			return new iPhone();
		}
		return null;
	}
	
}
