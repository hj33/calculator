package com.hw.test;

// 상속
public class iPhone implements Phone{

	@Override
	public void powerOn() {
		System.out.println("아이폰: 전원 켜기");
	}

	@Override
	public void powerOff() {
		System.out.println("아이폰: 전원 끄기");
	}

	@Override
	public void volumeUp() {
		System.out.println("아이폰: 전화 볼륨 up!");
	}

	@Override
	public void volumeDown() {
		System.out.println("아이폰: 전화 볼륨 down!");
	}
	
}
