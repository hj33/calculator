package com.hw.test;

public interface Phone {

	public void powerOn();
	public void powerOff();
	public void volumeUp();
	public void volumeDown();
	
}
