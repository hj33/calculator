package com.hw.test;

public class PhoneUser {

	public static void main(String[] args) {
		
		PhoneFactory fac = new PhoneFactory();
		Phone p = fac.getBean("Galaxy");
		
		p.powerOn();
		p.volumeUp();
		p.volumeDown();
		p.powerOff();
		
		
	}
	
}
